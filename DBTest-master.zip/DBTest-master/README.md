# DBTest
This is a small program that retrieves data from a database.
