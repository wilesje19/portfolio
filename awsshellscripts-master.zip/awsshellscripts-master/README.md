# awsshellscripts

Scripts to provision Ubuntu with Apache2 web server.
